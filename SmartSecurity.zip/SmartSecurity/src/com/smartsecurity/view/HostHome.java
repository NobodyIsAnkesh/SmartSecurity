package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.controller.EmployeeController;
import com.smartsecurity.model.Admin;
import com.smartsecurity.model.Employee;
import com.smartsecurity.model.Host;

/**
 * Servlet implementation class HostHome
 */
@WebServlet("/HostHome")
public class HostHome extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HostHome() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession ses = request.getSession();
		PrintWriter out = response.getWriter();
		
		out.println("<html>"
				+"<head>"
				+"<link rel='stylesheet' href='picture/AdminHome.css'/>"
				+"</head>"
			
				+ "<body style='font-family: arial'>");
		Host h;
		Employee e;
		try {
			h = (Host)ses.getValue("HOSTSESSION");
			String loginTime = (String)ses.getValue("HOSTLOGINTIME");
			e= EmployeeController.getEmployeeById(Integer.parseInt(h.getHostId()));
			String navbar="<div><b><h4><img src=picture/employee/"+e.getEmployeePhoto()
			+" width=65 height=65>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Host Id:"+h.getHostId()+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>"+e.getEmployeeName()
			+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>"+loginTime
			+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
			+ "<b><a href=HostLogout>Logout</a></h4></b></div>";
			out.println(navbar);
			
		} catch (Exception exp) {
			out.println(exp);
			response.sendRedirect("HostLogin");
		}
		
		out.println("<table class=a1>"
				+ "<tr>"
				+ "<td valign=top>"
				+ "<br><p><a href=SearchVisitor target=frame>Submit Visitor</a><br><br>"
				+ "<a href=ExitView target=frame>Exit Visitor</a><br><br>"
				+ "</td>"
				+ "<td valign=top>"
				+ "<iframe name=frame width=1100 height=700 frameborder=0></iframe>"
				+ "</td></tr></table></body></html>");
		out.flush();
	}

}
