package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;
import com.smartsecurity.controller.RfidController;
import com.smartsecurity.model.Host;

/**
 * Servlet implementation class VisitView
 */
@WebServlet("/VisitView")
public class VisitView extends HttpServlet implements LocationsEntry {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisitView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		HttpSession session= request.getSession();
		String visitorId= (String) session.getValue("VISITORIDSESSION");
		Host host= (Host) session.getValue("HOSTSESSION");
		
		String readRfid= "Reading...";
		out.println("<html>");
		out.println("<script src='asset/jquery-3.2.1.min.js'></script>"
				+ "<script src='asset/personsearch.js'></script>");
		String rfid= RfidController.getRfid(LOCATION_HOST);
		if(rfid==null) rfid= readRfid;
		if(rfid==readRfid || rfid.length()!=12){
			out.println("<meta http-equiv=\"refresh\" content=\"3\">");
		} else {
			out.println("<meta http-equiv=\"refresh\" content=\"-1\">");
		}
		
		out.println(
				  "<table><tr><td>"
				+ "<form action='VisitSubmit' method='post'>"
				+ "<table>"
				+ "<caption><b><i>Visit Information</i></b></caption>"
				
				+ "<tr><td><b><i>Host ID:</i></b></td>"
				+ "<td><input type=text readonly=true name=vhost size=30 value='"+ host.getHostId()+"'></td></tr>"

				+ "<tr><td><b><i>Visitor ID:</i></b></td>"
				+ "<td><input type=text readonly=true name=vid size=30 value='"+ visitorId+"'></td></tr>"
				
				+ "<tr><td><b><i>Visit RFID:</i></b></td>"
				+ "<td><input type=text readonly=true name=vrfid size=30 value='"+ rfid+"'></td></tr>"
				
				+ "<tr><td><b><i>Concerned Person</i></b></td>"
				+ "<td><input required type=text name=vdepartmentid id=vdepartmentid size=30></td>"
				+ "<td><input type='button' name='personbutt' id='personbutt' value='Search'></td></tr>"				
				
				+ "<tr><td><b><i>Visit Purpose:</i></b></td>"
				+ "<td><input required type=text name=vpurpose size=30></td></tr>"
				
				+ "<tr><td><b><i>Visit Checkout Time:</i></b></td>"
				+ "<td><input type=time name=vcheckout ></td></tr>"
				
				+ "</table><br>"
				+ "<input type=submit>&nbsp;&nbsp;<input type=reset></br>"
				+ "</form>"
				+ "</td>"
				+ "<td><div id='result'></div></td>"
				+ "</tr></table></html>");
		
		out.flush();
	}

}
