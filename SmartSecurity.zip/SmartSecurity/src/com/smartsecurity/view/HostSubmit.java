package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smartsecurity.contract.SmartSecurityContract.HostEntry;
import com.smartsecurity.controller.HostController;
import com.smartsecurity.model.Host;

/**
 * Servlet implementation class HostSubmit
 */
@WebServlet("/HostSubmit")
public class HostSubmit extends HttpServlet implements HostEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HostSubmit() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		String htmlFile= "<html>"
				+ "<body style='font-family: Arial'>"
				+ "<b>";
		
		Host host= new Host();
		host.setHostId(request.getParameter(COLUMN_HOST_HOST_ID));
		host.setHostPassword(request.getParameter(COLUMN_HOST_HOST_PASSWORD));
		boolean result= HostController.addNewHost(host);
		if(result)
			htmlFile+= "Visitor Exit Successfully Recorded";
		else
			htmlFile+= "Visitor Exit Record Failed to Submit";
		htmlFile+= "<b>"
				+ "</body>"
				+ "</html>";
		
		out.println(htmlFile);
		out.flush();
	}

}
