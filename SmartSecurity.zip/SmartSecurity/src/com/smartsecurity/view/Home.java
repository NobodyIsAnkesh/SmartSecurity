package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Home() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.println("<html>"
				+"<head>"
				+"<link rel='stylesheet' href='picture/home.css'/>"
				+"</head>"
				+ "<body>"
				+"<header>"
			     +"<h1>SMART SECURITY SYSTEM</h1>"
				+"</header>"
                 +"<section>"
				+"<div class=a1>"
				+ "<p><a href=AdminLogin >Admin login</a><br></p>"
				+"</div>"
				+"<div class=a2>"
				+ "<a href=HostLogin >Host login</a><br>"
				+"</div>"
				  +"</section>"
				+"<footer>"
				+"<h1>ABOUT </h1>"
				+"</footer>"
				+"<nav>"
			 
			    +"<p><a href=></a></p>"
			    +"<p><a href=></a></p>"
			    +"<p><a href=></a></p>"
			    +"</nav>"
			  
				+"</body>"
				+"</html>");
	}

}
