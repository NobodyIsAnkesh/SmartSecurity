package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.model.Admin;

/**
 * Servlet implementation class SearchTracking
 */
@WebServlet("/SearchTracking")
public class SearchTracking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchTracking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
				
		HttpSession session= request.getSession();
		try {
			Admin a= (Admin) session.getValue("ADMINSESSION");
			a.getAdminId();
		} catch (Exception e) {
			response.sendRedirect("Home");
		}

		String htmlFile= 
				  "<script src='asset/jquery-3.2.1.min.js'></script>"
				+ "<script src='asset/track.js'></script>"
				+ "<html>"
				+ "		<body style='font-family: Arial'>"
				+ "			<table cellspacing=3>"
				+ " 			<tr>"
				+ "					<td><input type=number name='searchtext' id='searchtext' placeholder='Search by Visitor ID...'></td>"
				+ "					<td>Between Dates	From: </td>"
				+ "					<td><input type=date name='fdate' id='fdate' ></td>"
				+ "					<td>	To </td>"
				+ "					<td><input type=date name='tdate' id='tdate' ></td>"
				+ "				</tr>"
				+ "			</table><br>"
				+ "			<input type=button name=searchbutt value=Search id=searchbutt>"
				+ "			<div id=count></div>"
				+ "			<div id=result></div>"
				+ "		</body>"
				+ "</html>";
		
		out.println(htmlFile);
	}

}
