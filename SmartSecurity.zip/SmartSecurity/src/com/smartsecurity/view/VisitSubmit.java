package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;
import com.smartsecurity.controller.DBHelper;
import com.smartsecurity.controller.RfidAllotedController;
import com.smartsecurity.controller.RfidController;
import com.smartsecurity.controller.TrackController;
import com.smartsecurity.controller.VisitController;
import com.smartsecurity.model.RfidAlloted;
import com.smartsecurity.model.Track;
import com.smartsecurity.model.Visit;

/**
 * Servlet implementation class VisitSubmit
 */
@WebServlet("/VisitSubmit")
public class VisitSubmit extends HttpServlet implements LocationsEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VisitSubmit() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		out.println("<html>");

		Visit V = new Visit();
		V.setVisitVisitorId(request.getParameter("vid"));
		V.setVisitRFID(request.getParameter("vrfid"));
		V.setVisitDepartmentId(request.getParameter("vdepartmentid"));
		V.setVisitPurpose(request.getParameter("vpurpose"));
		V.setVisitDate(DBHelper.getSQLFormatDate());
		V.setVisitCheckinTime(DBHelper.getSQLFormatTime());
		V.setVisitCheckoutTime(request.getParameter("vcheckout"));
		V.setVisitStatus("in");
		V.setVisitHost(request.getParameter("vhost"));
		
		
		boolean st = VisitController.AddNewRecord(V);
		
		
		if (st) {
			out.println("<b>Record Submitted</b>");
			
			RfidAlloted ra= new RfidAlloted();
			ra.setRfidAllotedRfid(V.getVisitRFID());
			ra.setRfidAllotedVisitorId(V.getVisitVisitorId());
			ra.setRfidAllotedVisitId(VisitController.getLastVisitId());
			boolean rs= RfidAllotedController.allotRfid(ra);
			
			boolean res= RfidController.deleteRfid(LOCATION_HOST);
			
			Track track= new Track();
			track.setTrackVisitorId(V.getVisitVisitorId());
			track.setTrackRfid(V.getVisitRFID());
			track.setTrackLocation(String.valueOf(LOCATION_HOST));
			track.setTrackTime(DBHelper.getSQLFormatTime().trim());
			track.setTrackDate(DBHelper.getSQLFormatDate().trim());
			track.setTrackVisitId(ra.getRfidAllotedVisitId());
			track.setTrackLocationStatus("in");
			boolean tr= TrackController.insertTrackDetails(track);
			
			if(tr)
				System.out.println("Tracked at "+ LOCATION_HOST);
			else
				System.out.println("Not Tracked!");
			if(!rs)
				System.out.println("RfidAlloted Record not Submitted!");
			if(!res)
				System.out.println("Rfid Not Deleted from DB!");
			
		} else {
			out.println("<b>Fail to Submit Record</b>");
		}
		out.println("</html>");
		out.flush();
	}

}
