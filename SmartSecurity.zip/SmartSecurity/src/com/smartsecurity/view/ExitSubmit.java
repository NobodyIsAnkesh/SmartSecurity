package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smartsecurity.contract.SmartSecurityContract.ExitEntry;
import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;
import com.smartsecurity.controller.DBHelper;
import com.smartsecurity.controller.ExitController;
import com.smartsecurity.controller.RfidAllotedController;
import com.smartsecurity.controller.TrackController;
import com.smartsecurity.controller.VisitController;
import com.smartsecurity.model.Exit;
import com.smartsecurity.model.RfidAlloted;
import com.smartsecurity.model.Track;

/**
 * Servlet implementation class ExitSubmit
 */
@WebServlet("/ExitSubmit")
public class ExitSubmit extends HttpServlet implements ExitEntry, LocationsEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExitSubmit() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		String htmlFile= "<html>"
				+ "<body style='font-family: Arial'>"
				+ "<b>";
		
		Exit exit= new Exit();
		exit.setExitRFID(request.getParameter(COLUMN_EXIT_RFID));
		exit.setExitDate(DBHelper.getSQLFormatDate());
		exit.setExitTime(DBHelper.getSQLFormatTime());
		
		
		boolean result= ExitController.insertExitRecord(exit);
		if(result)
			htmlFile+= "Visitor Exit Successfully Recorded";
		else
			htmlFile+= "Visitor Exit Record Failed to Submit";
	
		
		RfidAlloted ra= RfidAllotedController.getAllotedRfidDetails(exit.getExitRFID());
		Track track= new Track();
		track.setTrackRfid(exit.getExitRFID());
		track.setTrackVisitorId(ra.getRfidAllotedVisitorId());
		track.setTrackLocation(String.valueOf(LOCATION_HOST));
		track.setTrackDate(DBHelper.getSQLFormatDate());
		track.setTrackTime(DBHelper.getSQLFormatTime());
		track.setTrackVisitId(ra.getRfidAllotedVisitId());
		track.setTrackLocationStatus("out");
		
		boolean tr= TrackController.insertTrackDetails(track);
		if(tr)
			System.out.println("Tracked at "+ LOCATION_HOST);
		else
			System.out.println("Track failed!");
		
		boolean rs= RfidAllotedController.deleteAllotedRfid(exit.getExitRFID().trim());
		if(!rs)
			System.out.println("RfidAlloted Record not deleted from DB!");
		
		htmlFile+= "<b>"
				+ "</body>"
				+ "</html>";
		
		out.println(htmlFile);
		out.flush();
	}

}
