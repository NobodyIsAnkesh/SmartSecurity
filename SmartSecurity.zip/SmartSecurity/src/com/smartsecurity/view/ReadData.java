package com.smartsecurity.view;

import java.io.*;
import java.util.*;

import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;
import com.smartsecurity.controller.DBHelper;
import com.smartsecurity.controller.RfidAllotedController;
import com.smartsecurity.controller.RfidController;
import com.smartsecurity.controller.TrackController;
import com.smartsecurity.model.RfidAlloted;
import com.smartsecurity.model.Track;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.*;

public class ReadData implements Runnable, SerialPortEventListener, LocationsEntry {
	static CommPortIdentifier portId;
	String rfid = null;

	InputStream inputStream;
	SerialPort serialPort;
	Thread readThread;
	String value = new String();
	int location;

	public ReadData(String name, String comPort, int location) {
        System.out.println("I Am here....");
		this.location = location;

		try {
			portId = CommPortIdentifier.getPortIdentifier(comPort);
			serialPort = (SerialPort) portId.open(name, 2000);

			inputStream = serialPort.getInputStream();

			serialPort.addEventListener(this);

			serialPort.notifyOnDataAvailable(true);

			serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
		} catch (Exception e) {
			System.out.println(e);
		}

		readThread = new Thread(this);
		readThread.start();
	}

	public void run() {
		try { 
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

	}

	public String getRFID() {
		return rfid;
	}

	public void setRFID(String rfid) {
		this.rfid = rfid;
	}

	public void serialEvent(SerialPortEvent event) {
		System.out.println("Ia m here....");
		switch (event.getEventType()) {
		case SerialPortEvent.BI:
		case SerialPortEvent.OE:
		case SerialPortEvent.FE:
		case SerialPortEvent.PE:
		case SerialPortEvent.CD:
		case SerialPortEvent.CTS:
		case SerialPortEvent.DSR:
		case SerialPortEvent.RI:
		case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
			break;
		case SerialPortEvent.DATA_AVAILABLE:
			// byte[] readBuffer = new byte[12];

			try {
				DataInputStream D = new DataInputStream(inputStream);
				value = D.readLine();
				System.out.println(value);
				RfidController.insertRfid(value, location);
				
				if(location!=LOCATION_HOST){
					
					System.out.println("Entered Here!");
					
					RfidAlloted ra= RfidAllotedController.getAllotedRfidDetails(value.trim());
					
					Track track= new Track();
					track.setTrackVisitorId(ra.getRfidAllotedVisitorId());
					track.setTrackRfid(ra.getRfidAllotedRfid());
					track.setTrackLocation(String.valueOf(location));
					track.setTrackDate(DBHelper.getSQLFormatDate());
					track.setTrackTime(DBHelper.getSQLFormatTime());
					System.out.println("aaa");
					track.setTrackVisitId(ra.getRfidAllotedVisitId());
					System.out.println("bbb");
					String locStatus= TrackController.getLocationStatus(ra.getRfidAllotedVisitId(), location);
					if(locStatus==null) track.setTrackLocationStatus("in");
					else{
						String locationStatus= 
								locStatus.equals("in")?	"out": "in";
						System.out.println("location status: "+ locationStatus);
						track.setTrackLocationStatus(locationStatus);
					}
					
					boolean res= TrackController.insertTrackDetails(track);
					if(res)
						System.out.println("Tracked at "+ location);
					else
						System.out.println("Tracking failed!");
					
					boolean rs= RfidController.deleteRfid(location);
					if(!rs)
						System.out.println("Rfid NOT Deleted From DB!");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}