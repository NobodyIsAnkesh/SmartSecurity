package com.smartsecurity.view;

import java.util.*;

import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;

public class RFID implements LocationsEntry {

	public static void main(String args[]) {
		
		ReadData R = new ReadData("Amit", "COM3", LOCATION_HOST);
        Scanner KB = new Scanner(System.in);
		KB.nextLine();
	}
}
 