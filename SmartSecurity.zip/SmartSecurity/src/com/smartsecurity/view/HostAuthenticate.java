package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.contract.SmartSecurityContract.HostEntry;
import com.smartsecurity.controller.AdminCntroller;
import com.smartsecurity.controller.HostController;
import com.smartsecurity.model.Admin;
import com.smartsecurity.model.Host;

/**
 * Servlet implementation class HostAuthenticate
 */
@WebServlet("/HostAuthenticate")
public class HostAuthenticate extends HttpServlet implements HostEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HostAuthenticate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		
		String hostId= request.getParameter(COLUMN_HOST_HOST_ID).trim();
		String hostPassword= request.getParameter(COLUMN_HOST_HOST_PASSWORD);
		
		Host host= HostController.authenticateHost(hostId, hostPassword);
		
		if(host==null){
			System.out.println("Invalid Id/Password");
			out.println("<html>"
					+ "  <body style='font-family: Arial'>"
					+ "		<b>Invalid Id or Password</b>"
					+ "		<br><b>Try Again</b>"
					+ "	 </body>"
					+ "	 </html>");
			
		} else {
			HttpSession session= request.getSession();
			session.putValue("HOSTSESSION", host);
			session.putValue("HOSTLOGINTIME", new java.util.Date().toString());
			
			response.sendRedirect("HostHome");
		}
	}

}
