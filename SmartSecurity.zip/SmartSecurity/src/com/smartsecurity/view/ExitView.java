package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.contract.SmartSecurityContract.ExitEntry;
import com.smartsecurity.contract.SmartSecurityContract.LocationsEntry;
import com.smartsecurity.controller.RfidController;
import com.smartsecurity.model.Host;

/**
 * Servlet implementation class ExitView
 */
@WebServlet("/ExitView")
public class ExitView extends HttpServlet implements ExitEntry, LocationsEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExitView() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		HttpSession session= request.getSession();
		
		
		/*try {
			String visitorId= (String) session.getValue("VISITORIDSESSION");
			Host host= (Host) session.getValue("HOSTSESSION");
			host.getHostId();
		} catch (Exception e) {
			response.sendRedirect("HostLogin");
		}*/
		
		String readRfid= "Reading...";
		out.println("<html>");
		String rfid= RfidController.getRfid(LOCATION_HOST);
		if(rfid==null) rfid= readRfid;
		if(rfid==readRfid || rfid.length()!=12){
			out.println("<meta http-equiv=\"refresh\" content=\"3\">");
		} else {
			boolean rs= RfidController.deleteRfid(LOCATION_HOST);
			if(!rs)
				System.out.println("Rfid NOT Deleted From DB!");
			out.println("<meta http-equiv=\"refresh\" content=\"-1\">");
		}
		
		
		String htmlFile = 
				  "<body style='font-family: Arial'>"
				+ "	<form action='ExitSubmit' method='post'>"
				+ "	<table>"
				+ "		<caption><b>Visitor Exit</b></caption>"
				+ "		<tr>"
				+ "			<td><b>RFID: </b></td>"
				+ "			<td><input type='text' readonly=true value='"+ rfid+"' name='"+ COLUMN_EXIT_RFID+"' size='45'></td>"
				+ "		</tr>"
				+ "	</table>"
				+ "	<br>"
				+ "	<input type='submit'>&nbsp;&nbsp;"
				+ "	<input type='reset'>"
				+ "	<br>"
				+ "</form>"
				+ "</body>"
				+ "</html>";
		
		out.println(htmlFile);
		out.flush();
	}

}
