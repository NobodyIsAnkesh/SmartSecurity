package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.contract.SmartSecurityContract.AdminEntry;
import com.smartsecurity.model.Admin;

/**
 * Servlet implementation class AdminHome
 */
@WebServlet("/AdminHome")
public class AdminHome extends HttpServlet implements AdminEntry {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminHome() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession ses = request.getSession();
		PrintWriter out = response.getWriter();
		out.println("<html>"
				+"<head>"
				+"<link rel='stylesheet' href='picture/AdminHome.css'/>"
				+"</head>"
				+ "<body style='font-family: Arial'>");
		Admin A;
		try {
			A = (Admin)ses.getValue("ADMINSESSION");
			String loginTime = (String)ses.getValue("SESSIONLOGINTIME");
			String navbar="<div><b><h4><img src=picture/"+A.getAdminPicture()
			+" width=65 height=65>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin Id:"+A.getAdminId()+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>"+A.getAdminName()
			+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>"+loginTime
			+"</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
			+ "<b><a href=AdminLogout>Logout</a></h4></b></div>";
			out.println(navbar);
			
		} catch (Exception e) {
			out.println(e);
			response.sendRedirect("AdminLogin");
		}
		
		out.println("<table class=a1>"
				+ "<tr>"
				+ "<td valign=top>"
				+ "<p><br><a href=EmployeeView target=frame>Add Employee</a><br><br>"
				+ "<a href=EmployeeDisplayAll target=frame>Display Employees</a><br><br>"
				+ "<a href=EmployeeById target=frame>Edit Delete</a><br>"
				+"<h5> </h5>"
				+ "<br><a href=DepartmentView target=frame>Add Department</a><br><br>"
				+ "<a href=DepartmentDisplayAll target=frame>Display Departments</a><br><br>"
				+"<h5> </h5>"
				+ "<a href=VisitDisplayAll target=frame>View All Visits</a><br><br>"
				+ "<a href=ReportView target=frame>Search Visits</a><br><br>"
				+ "<a href=VisitorDisplayAll target=frame>View All Visitors</a><br><br>"
				+ "<a href=SearchTracking target=frame>Search Live Tracking</a><br><br>"
				+"<h5> </h5>"
				+ "<a href=HostView target=frame>Add Host</a><br><br></p>"
				+ "</td>"
				+ "<td valign=top>"
				+ "<iframe name=frame width=1200 height=550 frameborder=0></iframe>"
				+ "</td></tr></table></body></html>");
		out.flush();
	}

}
