package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smartsecurity.controller.VisitorController;
import com.smartsecurity.model.Admin;
import com.smartsecurity.model.Visitor;

/**
 * Servlet implementation class DisplayVisitor
 */
@WebServlet("/DisplayVisitor")
public class DisplayVisitor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayVisitor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		
		HttpSession session= request.getSession();
		try {
			Admin a= (Admin) session.getValue("ADMINSESSION");
			a.getAdminId();
		} catch (Exception e) {
			response.sendRedirect("Home");
		}
		
		Visitor v= VisitorController.getVisitorById(request.getParameter("vid"));
		
		String state= v.getVisitorState();
		String city= v.getVisitorCity();
		
		String st[]= state.split(",");
		String ct[]= city.split(",");
		
		String htmlFile = 
				  "<script src='asset/jquery-3.2.1.min.js'></script>"
				+ "<script src='asset/statecity.js'></script>"
				+ "<html>"
				+ "<body style='font-family: Arial'>"
				+ "	<table>"
				+ "		<caption><b>Visitor Details</b></caption>"
				+ "		<tr>"
				+ "			<td><b>Employee ID: </b></td>"
				+ "			<td>"+ v.getVisitorEmployeeId() +"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Visitor Name: </b></td>"
				+ "			<td>"+ v.getVisitorName()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Address: </b></td>"
				+ "			<td>"+ v.getVisitorAddress()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>State: </b></td>"
				+ "			<td>"+ st[1]+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>City: </b></td>"
				+ "			<td>"+ ct[1]+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Mobile No.: </b></td>"
				+ "			<td>"+ v.getVisitorMobile()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Email ID: </b></td>"
				+ "			<td>"+ v.getVisitorEmailId()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Identification No.: </b></td>"
				+ "			<td>"+ v.getVisitorIdentificationNo()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Identification Type: </b></td>"
				+ "			<td>"+ v.getVisitorIdentificationType()+"</td>"
				+ "		</tr>"
				+ "		<tr>"
				+ "			<td><b>Photograph: </b></td>"
				+ "			<td><image src='picture/visitor/"+v.getVisitorPicture()+"' width=120 height=120></td>"
				+ "		</tr>"
				+ "	</table>"
				+ "	<br>"
				+ "	<br>"
				+ "</body>"
				+ "</html>";
		
		out.println(htmlFile);
		out.flush();
	}

}
