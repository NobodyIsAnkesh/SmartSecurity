package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.smartsecurity.controller.VisitorController;

/**
 * Servlet implementation class VisitorSearchByMobile
 */
@WebServlet("/VisitorSearchByMobile")
public class VisitorSearchByMobile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VisitorSearchByMobile() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		HttpSession session= request.getSession();
		
			if(session==null)
				response.sendRedirect("HostLogin");
		
		String mobile= request.getParameter("mobile");
		System.out.println(mobile);
		String visitorId= VisitorController.getVisitorIdByMobile(mobile);
		JSONObject obj= new JSONObject();
		try{
			if(visitorId!=null){
				obj.put("VISITORID", visitorId);
				session.putValue("VISITORIDSESSION", visitorId);
			}
			else{
				obj.put("VISITORID", "Nil");
				session.putValue("MOBILENOSESSION", mobile);
			}
				
			out.println(obj);
		} catch(Exception e){
			out.println(obj);
		}
		
	}

}
