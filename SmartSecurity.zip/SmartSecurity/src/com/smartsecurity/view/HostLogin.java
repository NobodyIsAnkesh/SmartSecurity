package com.smartsecurity.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smartsecurity.contract.SmartSecurityContract.HostEntry;

/**
 * Servlet implementation class HostLogin
 */
@WebServlet("/HostLogin")
public class HostLogin extends HttpServlet implements HostEntry {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HostLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String htmlFile = 

				  "<html>"
						  +"<head>"
							+"<link rel='stylesheet' href='picture/HostLogin.css'/>"
							+"</head>"
				+ "<body style='font-family: 'Lato', sans-serif'>"
				+"<header>"
			     +"<h1>HOST LOGIN</h1>"
				+"</header>"
				+ "	<form action='HostAuthenticate' method='post'>"
				  +"<Section>"
			
				+ "	<table class=a1>"
			
                + "		<tr>"

				+ "			<td ><h2><b>Host ID: </b></h2></td>"
				+ "			<td><h2><input type='text' name='"+COLUMN_HOST_HOST_ID+"' size='30'></h2></td>"
			
				
				+ "		</tr>"
				+ "		<tr>"
				
				+ "			<td><h2><b>Host Password: </b></h2></td>"
				+ "			<td><h2><input type='password' name='"+COLUMN_HOST_HOST_PASSWORD+"' size='30'></h2></td>"
				
				+ "		</tr>"
	            + "		<tr>"
				+ "	<td></td><td>&nbsp;&nbsp;"
				+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Login'>&nbsp;&nbsp;"
				+ "	<input type='reset'></td>"
				+ "		</tr>"
				+ "	</table>"
				+"</Section>"
				+ "	<br>"
				+ "</form>"
				+ "</body>"
				+ "</html>";
		
		out.println(htmlFile);
		out.flush();
	}

}
