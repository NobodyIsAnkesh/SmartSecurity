package com.smartsecurity.model;

public class Visitor {
	
	private String visitorEmployeeId;
	private String visitorId;
	private String visitorName;
	private String visitorAddress;
	private String visitorCity;
	private String visitorState;
	private String visitorMobile;
	private String visitorEmailId;
	private String visitorIdentificationNo;
	private String visitorIdentificationType;
	private String visitorPicture;
	
	
	public void setVisitorEmployeeId(String visitorEmployeeId) {
		this.visitorEmployeeId = visitorEmployeeId;
	}
	public void setVisitorId(String visitorId) {
		this.visitorId = visitorId;
	}
	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}
	public void setVisitorAddress(String visitorAddress) {
		this.visitorAddress = visitorAddress;
	}
	public void setVisitorCity(String visitorCity) {
		this.visitorCity = visitorCity;
	}
	public void setVisitorState(String visitorState) {
		this.visitorState = visitorState;
	}
	public void setVisitorMobile(String visitorMobile) {
		this.visitorMobile = visitorMobile;
	}
	public void setVisitorEmailId(String visitorEmailId) {
		this.visitorEmailId = visitorEmailId;
	}
	public void setVisitorIdentificationNo(String visitorIdentificationNo) {
		this.visitorIdentificationNo = visitorIdentificationNo;
	}
	public void setVisitorIdentificationType(String visitorIdentificationType) {
		this.visitorIdentificationType = visitorIdentificationType;
	}
	public void setVisitorPicture(String visitorPicture) {
		this.visitorPicture = visitorPicture;
	}
	
	
	public String getVisitorEmployeeId() {
		return visitorEmployeeId;
	}
	public String getVisitorId() {
		return visitorId;
	}
	public String getVisitorName() {
		return visitorName;
	}
	public String getVisitorAddress() {
		return visitorAddress;
	}
	public String getVisitorCity() {
		return visitorCity;
	}
	public String getVisitorState() {
		return visitorState;
	}
	public String getVisitorMobile() {
		return visitorMobile;
	}
	public String getVisitorEmailId() {
		return visitorEmailId;
	}
	public String getVisitorIdentificationNo() {
		return visitorIdentificationNo;
	}
	public String getVisitorIdentificationType() {
		return visitorIdentificationType;
	}
	public String getVisitorPicture() {
		return visitorPicture;
	}
	
}
