package com.smartsecurity.model;

public class RfidAlloted {
	
	private String rfidAllotedRfid;
	private String rfidAllotedVisitorId;
	private String rfidAllotedVisitId;
	
	
	public void setRfidAllotedRfid(String rfidAllotedRfid) {
		this.rfidAllotedRfid = rfidAllotedRfid;
	}
	public void setRfidAllotedVisitorId(String rfidAllotedVisitorId) {
		this.rfidAllotedVisitorId = rfidAllotedVisitorId;
	}
	public void setRfidAllotedVisitId(String rfidAllotedVisitId) {
		this.rfidAllotedVisitId = rfidAllotedVisitId;
	}
	
	
	
	public String getRfidAllotedRfid() {
		return rfidAllotedRfid;
	}
	public String getRfidAllotedVisitorId() {
		return rfidAllotedVisitorId;
	}
	public String getRfidAllotedVisitId() {
		return rfidAllotedVisitId;
	}
	
	
}
