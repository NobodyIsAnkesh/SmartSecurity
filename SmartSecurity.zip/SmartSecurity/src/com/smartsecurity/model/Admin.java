package com.smartsecurity.model;

public class Admin {
	
	private String adminId;
	private String adminName;
	private String adminPicture;
	private String adminPassword;
	
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public void setAdminPicture(String adminPicture) {
		this.adminPicture = adminPicture;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
	
	public String getAdminId() {
		return adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public String getAdminPicture() {
		return adminPicture;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	
	
}
