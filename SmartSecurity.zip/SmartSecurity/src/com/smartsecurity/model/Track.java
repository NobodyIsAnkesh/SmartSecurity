package com.smartsecurity.model;

public class Track {

	private String trackId;
	private String trackVisitorId;
	private String trackRfid;
	private String trackLocation;
	private String trackTime;
	private String trackDate;
	private String trackVisitId;
	private String trackLocationStatus;
	
	public String getTrackLocationStatus() {
		return trackLocationStatus;
	}
	public void setTrackLocationStatus(String trcakLocationStatus) {
		this.trackLocationStatus = trcakLocationStatus;
	}
	public void setTrackId(String trackId) {
		this.trackId = trackId;
	}
	public void setTrackVisitorId(String trackVisitorId) {
		this.trackVisitorId = trackVisitorId;
	}
	public void setTrackRfid(String trackRfid) {
		this.trackRfid = trackRfid;
	}
	public void setTrackLocation(String trackLocation) {
		this.trackLocation = trackLocation;
	}
	public void setTrackTime(String trackTime) {
		this.trackTime = trackTime;
	}
	public void setTrackDate(String trackDate) {
		this.trackDate = trackDate;
	}
	public void setTrackVisitId(String trackVisitId) {
		this.trackVisitId = trackVisitId;
	}
	
	
	
	public String getTrackId() {
		return trackId;
	}
	public String getTrackVisitorId() {
		return trackVisitorId;
	}
	public String getTrackRfid() {
		return trackRfid;
	}
	public String getTrackLocation() {
		return trackLocation;
	}
	public String getTrackTime() {
		return trackTime;
	}
	public String getTrackDate() {
		return trackDate;
	}
	public String getTrackVisitId() {
		return trackVisitId;
	}
	
	
	
	
	
}
