$(document).ready(function(){
	$('#searchbutt').click(function(){
		
//		$mob= $('#mobile').val();
//		if($mob.length() >10)
//			alert("Mobile no. length cannot exceed 10 digits!")
//		else{
			$.getJSON('VisitorSearchByMobile',
					{ajax:true, mobile:$('#mobile').val()},
					function(data, item){
						if(data.VISITORID == "Nil"){
							alert("Mobile no. Not Found!");
							window.location.href= 'VisitorView';
						}
						else
							window.location.href= 'VisitView';
					});
//		}
		
	});
});