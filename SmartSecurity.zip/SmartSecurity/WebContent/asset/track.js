var refreshing = false;

function displayTracks(){
	
	$.getJSON('TrackSearchJSON', {ajax:true, fdate:$('#fdate').val(), tdate:$('#tdate').val(), searchtext: $('#searchtext').val()}, function(data){
		$htm= "<table cellspacing=5 border=1>"
			+ "<caption>Tracking Details</caption>"
			+ "<tr><th>Track Id</th><th>Visitor ID</th><th>Visit RFID</th><th>Location</th>"
			+ "<th>Status</th><th>Time</th><th>Date</th>"
			+ "<th>Visit ID</th><th>View Visitor</th></tr>";

		$.each(data, function(i, item){
			$htm+="<tr>";
			$htm+= "<td>"+ item.IDTRACK+"</td>"
				 + "<td>"+ item.VID+"</td>"
				 + "<td>"+ item.VRFID+"</td>"
				 + "<td>"+ item.DNAME+"</td>"
				 + "<td>"+ item.LSTATUS+"</td>"
				 + "<td>"+ item.TIME+"</td>"
				 + "<td>"+ item.DATE+"</td>"
				 + "<td>"+ item.VISITID+"</td>"
				 + "<td><a href='DisplayVisitor?vid="+ item.VID+"'>Click Here</a></td>"
				 + "</tr>" ;
		});
		
		$htm+= "</table>";
		
		$('#result').html($htm);
		
	});
}

function refresh() {
		setTimeout(function() {
			displayTracks();
			refresh();
		}, 3000);	
}

$(document).ready( function(){
	
	
	
	$('#searchbutt').click(function(){
		if(($('#fdate').val()=="" || $('#fdate').val()==null) && !($('#tdate').val()=="" || $('#tdate').val()=="")
				|| (!($('#fdate').val()=="" || $('#fdate').val()==null) && ($('#tdate').val()=="" || $('#tdate').val()==""))){
				alert("Enter both dates or none!");
		}
		else{
			displayTracks();
			refresh();
		}
			
	});
		
});