
function displayEmployee(){
	
	$.getJSON('EmployeeSearchJSON', {ajax:true, employee:$('#vdepartmentid').val()}, function(data){
		$htm= "<table cellspacing=5>";

		$.each(data, function(i, item){
			$htm+="<tr>";
			$htm+= "<td>"
				 + "<table cellspacing=10>"
				 + "<tr>"
				 + "<td ><img src=picture/employee/"+ item.EPHOTO+ " width=120 height=120></td>"
				 + "<td>"
				 + "<b>Employee ID: </b>"+ item.EID+ "<br>"
				 + "<b>Name: </b>"+ item.ENAME+ "<br>"
				 + "<b>Department: </b>"+ item.EDEPARTMENT+ "<br>"
				 + "</td></tr></table></td></tr>" ;
		});
		
		$htm+= "</table>";
		
		$('#result').html($htm);
		
	});
}

$(document).ready( function(){
	
	$('#personbutt').click(function(){
		if($('#vdepartmentid').val()==null || $('#vdepartmentid').val()==""){
				alert("Enter Name first!");
		}
		else{
			displayEmployee();
		}
			
	});
		
});