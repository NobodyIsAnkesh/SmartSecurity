
function displayVisitors(){
	
	$.getJSON('VisitorsBetweenDatesJSON', {ajax:true, fdate:$('#fdate').val(), tdate:$('#tdate').val(), status:$('input[name=status]:checked').val(), search: $('input[name=search]:checked').val(), searchtext: $('#searchtext').val()}, function(data){
		$htm= "<table cellspacing=5>";

		$.each(data, function(i, item){
			$htm+="<tr>";
			$htm+= "<td>"
				 + "<table cellspacing=10>"
				 + "<tr>"
				 + "<td ><img src=picture/visitor/"+ item.VPICTURE+ " width=120 height=120></td>"
				 + "<td>"
				 + "<b>Visitor ID: </b>"+ item.VID+ "<br>"
				 + "<b>Name: </b>"+ item.VNAME+ "<br>"
				 + "<b>Mobile: </b>"+ item.VMOBILE+ "<br>"
				 + "<b>RFID used: </b>"+ item.VRFID+ "<br>"
				 + "<b>Conc. Employee ID: </b>"+ item.VDEPARTMENTID+ "<br>"
				 + "</td>"
				 + "<td>"
				 + "<b>Purpose: </b>"+ item.VPURPOSE+ "<br>"
				 + "<b>Date: </b>"+ item.VDATE+ "<br>"
				 + "<b>Check In: </b>"+ item.VCHECKIN+ "<br>"
				 + "<b>Check Out: </b>"+ item.VCHECKOUT+ "<br>"
				 + "</td></tr></table></td></tr>" ;
		});
		
		$htm+= "</table>";
		
		$('#result').html($htm);
		
	});
}

$(document).ready( function(){
	
	$('input[type=radio][name=search]').change(function(){
		if($('input[name=search]:checked').val() != "0")
			$('#searchtext').prop('readonly', false);
		else
			$('#searchtext').prop('readonly', true);
	});
	
	$('#searchbutt').click(function(){
		if($('#fdate').val()=="" || $('#fdate').val()==null || $('#tdate').val()=="" || $('#tdate').val()=="")
			alert("Enter valid dates first!");
		else{
			
			displayVisitors();
		}
			
	});
		
});